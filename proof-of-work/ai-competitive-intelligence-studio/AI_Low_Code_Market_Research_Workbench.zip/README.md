# AI + Low-Code Market Research Workbench

## Purpose
A portfolio-ready prototype for a Market Research / Competitive Intelligence consultant. It combines an evidence-led research workflow with an AI analysis layer and a low-code automation blueprint.

## Core workflow
Research question → source collection → evidence extraction → triangulation → market sizing → competitive intelligence → AI synthesis → low-code refresh/notification → QC → client output.

## AI skills demonstrated
- Prompt engineering
- Evidence-grounded AI synthesis
- Research summarisation
- Hypothesis / implication generation
- Competitive intelligence support
- AI workflow design
- Source-aware analysis

## Low-code / no-code skills demonstrated
- Power Automate workflow design
- Power Query data transformation
- Power BI dashboard architecture
- Excel-based market sizing and assumptions
- SharePoint/OneDrive-style document triggers
- Approval / QC workflow concepts

## Important implementation note
The browser prototype does NOT itself call a live LLM, Power Automate, Power BI or external research API. The Automation page provides the architecture for connecting those services legitimately. This distinction should be retained in portfolio claims.

## Suggested portfolio description
Built an AI + low-code Market Research Workbench that structures source collection, evidence validation, market sizing, competitive intelligence and research QC, with an automation architecture spanning Power Automate, Power Query, Power BI and an approved LLM/API.

## Run
Open index.html in a modern browser.
